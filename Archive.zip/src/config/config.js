export const DATA_URL = "https://dnc0cmt2n557n.cloudfront.net/products.json";
